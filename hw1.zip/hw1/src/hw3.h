#pragma once

#include <vector>
#include <string>

void hw_3_1(const std::vector<std::string> &params);
void hw_3_2(const std::vector<std::string> &params);
void hw_3_3(const std::vector<std::string> &params);
void hw_3_4(const std::vector<std::string> &params);
