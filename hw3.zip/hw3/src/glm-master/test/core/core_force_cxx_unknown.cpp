#ifndef GLM_FORCE_CXX_UNKNOWN
#	define GLM_FORCE_CXX_UNKNOWN
#endif

#include <glm/glm.hpp>
#include <glm/ext.hpp>

int main()
{
	int Error = 0;

	return Error;
}

