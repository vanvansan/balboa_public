#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/handed_coordinate_space.hpp>

int main()
{
	int Error(0);

	return Error;
}
