scenes/hw3/myScene.json
outputs/myScene.mov